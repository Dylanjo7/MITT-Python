
input_str = input("Enter a Sentence:")

print ("The Sentence you typed is: " + input_str)

str_num = len(input_str.split())

print("The number of words in your sentence is: " + str(str_num))

input("Press Enter to Continue To the next step of the assignment:")
#just added this to clear terminal so its cleaner
import os
os.system('cls')

input_str_two = input("Enter a Sentence:")
input_num_two = int(input("Enter a Number:"))
input_word_two = input("Enter a Word:")

print("The Sentence you typed is: " + input_str_two)
print("The Number you Typed is: " + str(input_num_two))
print("The Word you Typed is: "  + input_word_two)

str_num_two = input_str_two.split()
str_num_two[input_num_two - 1] = input_word_two

print("Your New Sentence is: " + ' '.join(str_num_two))

input("Press Enter to Continue To the next step of the assignment:")
#just added this to clear terminal so its cleaner
import os
os.system('cls')

input_str_three = input("Enter a Sentence:")
input_num_three = int(input("Enter 1 for Odd Or 0 for Even :"))
input_word_three = input("Enter a Word:")

str_num_three = input_str_three.split()

for i in range (len(input_word_three)):
  if i % 2 == 0 and  input_num_three == 0:
    str_num_three[i] = input_word_three
  if 1 % 2 != 1 and  input_num_three == 1:
    str_num_three[i] = input_word_three

print("Your New Sentence is: " + ' '.join(str_num_three))



