# String Method Example 1
user_name = input("Enter a Username: ")

# capitalize() Method
# - Arguments: None
# - Required Arguments: None
# - Default Values: None
# - Returns: The Username or word With the first letter capitalized
cap_name = user_name.capitalize() # This Capitalizes user_name to cap_name
print("Your Username is: " + cap_name)


# String Method Example 2
i = 1

# len() Method
# - Arguments: password
# - Required Arguments: Required. An object. Must be a sequence or a collection
# - Default Value: None
# - Returns: The Number of digits in the word

# isspace() Method
# - Arguments: None
# - Required Arguments: None
# - Default Value: True or False
# - Returns: True or False based on if its all space
while i == True:
  password = input("Enter a Password: ")
  length_of_password = len(password)
  if ' ' in password or password.isspace() or length_of_password < 8:
    print("Password cannot contain spaces and be at least 8 characters. Please enter again.")
  else:
    print("Password accepted.")
    break