name = "bob"

num = "542"

quotes = "this is my string \"with quotes"
print(name[0])

for letter in name:
  print(letter)

print(quotes.capitalize())
