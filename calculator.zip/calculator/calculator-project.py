
while True:
  try:
    operator = input("What operation +-/*: ")
    break
  except:
    print("Invalid Input")
while True:
  try:
    fn = int(input("Enter Your First number: "))
    break
  except:
    print("Invalid Input")
while True:
  try:
    sn = int(input("Enter your Second Number: "))
    break
  except:
    print("Invalid Input")
  
final = 0
if operator == "+":
  final = fn + sn
elif operator == "-":
  final = fn - sn
elif operator == "/":
  final = fn / sn
elif operator == "*":
  final = fn * sn

print(final)