
sum = 0
count = 0
average = 0

while True:
    try:
        num = float(input("Enter a number (or any non-number to finish): "))
        sum = sum + num
        count = count + 1
    except ValueError:
        break

if count != 0:
    average = sum / count
    print("The average is: ", average)
else:
    print("No numbers were entered")