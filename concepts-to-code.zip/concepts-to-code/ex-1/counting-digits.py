number = input("Enter a Number: ")
digits = str(number)

rNumber = ""

for i in range(len(digits)):
  rNumber = str(number[i]) + rNumber
  
print(rNumber) 