num = int(input("Enter a Number: "))

if (num % 2) == 0:
  final = 2
  even = 2
  count = 1
  even = even + 2
  for count in range(num):
    final = final + count
    count = count + 1

else:
  final = 1
  odd = 1
  count = 1
  odd = odd + 2
  for count in range(num):
    final = final + count
    count = count + 1

print("The Sum of you number is: " + str(final))
