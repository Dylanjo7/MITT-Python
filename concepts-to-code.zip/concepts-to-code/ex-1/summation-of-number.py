sum = 0
num = int(input("Enter a Number: "))
i = 1

for i in range(num):
  sum = sum + i
  i = i + 1
  

print("The sum of numbers from 1 to", num, "is:", sum)