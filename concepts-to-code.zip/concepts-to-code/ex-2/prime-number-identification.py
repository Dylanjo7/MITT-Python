num = int(input("Enter a number: "))

nonPrime = False

if num == 1:
    print("This is not a prime number")
elif num > 1:
    
  for i in range(2, num):
    if (num % i) == 0:
      nonPrime = True
      break

if nonPrime == True:
  print("This is not a prime number")
else:
  print("This is a prime number")