username = "username"
password = "password"

userCorrect = False
passwordCorrect = False

userUsername = input("Enter Your Username: ")
userPassword = input("Enter Your Password: ")

if username == userUsername:
  userCorrect = True

if userCorrect == False:
  print("Wrong Username")

else:
  print("Correct Username")

if password == userPassword:
  passwordCorrect = True

if passwordCorrect == False:
  print("Wrong Password")

else:
  print("Correct Password")