num1 = int(input("Enter a Number: "))
num2 = int(input("Enter a Number: "))
num3 = int(input("Enter a Number: "))

biggerNum = 0

if num1 > num2:
  biggerNum = num1
else:
  biggerNum = num2

if biggerNum < num3:
  biggerNum = num3

print(biggerNum)