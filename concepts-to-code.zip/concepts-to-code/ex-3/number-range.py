ageRange = 18

age = int(input("Enter Your Age: "))

if age < 18 and age > 130:
  print("You Cannot Enter")

else:
  print("You are old enough")