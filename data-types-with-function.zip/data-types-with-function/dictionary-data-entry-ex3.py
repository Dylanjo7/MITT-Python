contacts = {}

for i in range(5):
  persons_name = input("Enter the person's name: ")
  persons_number = input("Enter the persons's contact number: ")

  contacts[persons_name.title()] = persons_number


print(contacts)

wanted_name = input("Who would you like to call?: ")

if persons_name == wanted_name:
  print(contacts["persons_name"])
