def merge(dict_1, dict_2):
  return dict_1 | dict_2

d1 = {'a': 2, 'b': 5, 'c': 3}
d2 = {'c': 20, 'd': 25, 'e': 30}

d3 = merge(d1, d2)
print(d3)