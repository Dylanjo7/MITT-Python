
def call_count(call):
  count = {}

  for x in call:
    count[x] = count.get(x, 0) + 1

  for x, frequency in count.items():
    print(f"Character: {x}, Frequency: {frequency}")

string = input("Enter a word with muiltiple of the same letters")


call_count(string)