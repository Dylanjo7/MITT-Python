d1 = {
  'title': "Book",
  'author' : "Dylan",
  'year' : 2000,
  'genre' : "fiction",

  'chapter': {
    (1, "Chapter 1", 20),
    (2, "Chapter 2", 30),
    (3, "Chapter 3", 40)
  }
  
}

print(d1)

def books(title, author, year, genre, chapter_data):
    book = {
      'title': "Book",
      'author' : "Dylan",
      'year' : 2000,
      'genre' : "fiction",
    }
    return book

# Example usage:
def chapters():
    chapter = {
        1: {"title": "Chapter 1", "pages": 20},
        2: {"title": "Chapter 2", "pages": 30},
        3: {"title": "Chapter 3", "pages": 40}
    }
    return chapter

chapters()
