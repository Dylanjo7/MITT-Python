def process_number_input(input_str):
    numbers = input_str.split()
    number_set = set()
    for num in numbers:
        number_set.add(int(num))
    return number_set

def compare_sets(set1, set2):
    common_elements = set1.intersection(set2)
    unique_elements_set1 = set1.difference(set2)
    unique_elements_set2 = set2.difference(set1)
    return common_elements, unique_elements_set1, unique_elements_set2

num1 = int(input("Enter a set of Number: "))
num2 = int(input("Enter another set of Number: "))

set1 = process_number_input(num1)
set2 = process_number_input(num2)

common_elements, unique_elements_set1, unique_elements_set2 = compare_sets(set1, set2)

print("Common Elements: ", common_elements)
print("Unique Elements in set1: ", unique_elements_set1)
print("Unique Elements in set2: ", unique_elements_set2)