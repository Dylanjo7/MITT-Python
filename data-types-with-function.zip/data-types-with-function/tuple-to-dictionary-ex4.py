students = ((100, 'Dylan'), (50, 'nic'), (40, 'gavin'))


{'Dylan': 100, 'nic': 50, 'gavin': 40}
def convert_to_d(students):
  return dict((y, x) for x, y in students)

students = ((100, 'Dylan'), (50, 'nic'), (40, 'gavin'))
d = convert_to_d(students)

print(d)