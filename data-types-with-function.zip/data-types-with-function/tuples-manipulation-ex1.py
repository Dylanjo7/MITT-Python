def reverse_tuple(input_tuple):
    reversed_list = list(input_tuple)
    reversed_list.reverse()
    return tuple(reversed_list)

numbers = (1, 2, 3, 4, 5)
reversed_numbers = reverse_tuple(numbers)

print(reversed_numbers)