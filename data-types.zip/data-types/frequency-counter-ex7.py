string = input("Enter a word with muiltiple of the same letters")

count = {}


for x in string:
  count[x] = count.get(x, 0) + 1

for x, frequency in count.items():
  print(f"Character: {x}, Frequency: {frequency}")