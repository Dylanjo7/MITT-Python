d1 = {
  'title': "Book",
  'author' : "Dylan",
  'year' : 2000,
  'genre' : "fiction",

  'chapter': {
    (1, "Chapter 1", 20),
    (2, "Chapter 2", 30),
    (3, "Chapter 3", 40)
  }
  
}

print(d1)