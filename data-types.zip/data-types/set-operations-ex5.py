
num_set = input("Enter numbers: ")
set1 = set(map(int, num_set.split()))

num_set = input("Enter numbers again: ")
set2 = set(map(int, num_set.split()))

union_set = set1.union(set2)
intersection_set = set1.intersection(set2)
difference_set1_2 = set1.difference(set2)
difference_set2_1 = set2.difference(set1)

symmetric_difference_set = set1.symmetric_difference(set2)

print("\nResults:")
print("Union:", union_set)
print("Intersection:", intersection_set)
print("Difference 1-2:", difference_set1_2)
print("Difference 2-1:", difference_set2_1)
print("Symmetric Difference:", symmetric_difference_set)