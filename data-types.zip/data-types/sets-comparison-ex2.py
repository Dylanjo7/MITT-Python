num1 = int(input("Enter a set of Number: "))
num2 = int(input("Enter another set of Number: "))

number1 = num1.split()
number2 = num2.split()

set1 = set()
set2 = set()

for num1 in number1:
  set1.add(int(num1))
  
for num2 in number2:
  set2.add(int(num2))

common_elements = set1.intersection(set2)

unique_elements_set1 = set1.difference(set2)
unique_elements_set2 = set2.difference(set1)

print("Common Elements: ", common_elements)
print("Unique Elements is set1: ", unique_elements_set1)
print("Unique Elements is set2: ", unique_elements_set2)