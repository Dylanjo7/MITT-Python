students = ((100, 'Dylan'), (50, 'nic'), (40, 'gavin'))

dict((y, x) for x, y in students)

{'Dylan': 100, 'nic': 50, 'gavin': 40}