numbers = (1, 2, 3, 4, 5)

reversedNum = list(numbers)

reversedNum = reversed(numbers)

print(tuple(reversedNum))