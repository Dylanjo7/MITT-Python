from dictionaries import *

# Takes the decimal and converts to the wanted output number or text

# converts the decimal number into the wanted binary output format
def dec_to_binary(dec_num):
  """
    Converts decimal to binary.

    Args:
        dec_num

    Returns:
        binary_output

    Raises:
        ValueError: If Brakes

    Note:
        None
    """
  # changing the dec_num to a int so the while loop works later
  dec_num = int(dec_num)
  # this is here just so if its zero you can just skip the rest of the code
  if dec_num == 0:
    return "0"

  # declaring the variable
  binary_output = ''
  # while dec_nums bigger then 0 the binary output is mogulo and adds itself then rest is basics and juts loops 
  while dec_num > 0:
    binary_output = str(dec_num % 2) + binary_output
    dec_num //= 2
  return binary_output


# converts the decimal number into the wanted hex output format
def dec_to_hex(dec_num):
  """
    Converts decimal to hex.

    Args:
        dec_num

    Returns:
        hex_output

    Raises:
        ValueError: If Brakes

    Note:
        None
    """
  # this is here just so if its zero you can just skip the rest of the code
  if dec_num == 0:
    return "0"


  hex_output = ''
  # changing the dec_num to a int so the while loop works later
  dec_num = int(dec_num)
  # while dec_nums bigger then 0 the same kind of thing as the binary. 
  # a couple things that are diffrent is the hex one calls for a dictionary at the top to find the letter values
  while dec_num > 0:
    remainder = dec_num % 16
    hex_digit = hex_d[remainder]
    hex_output = hex_digit + hex_output
    dec_num //= 16

  return hex_output

# converts the decimal number into the wanted ascii output format
def dec_to_ascii(dec_num):
  """
    Converts decimal to ascii.

    Args:
        dec_num

    Returns:
        ascii_output

    Raises:
        ValueError: If Brakes or if number is not between 0-127

    Note:
        None
    """
  # again changes the dec_num to int and checks if the number is in between 0 and 127 to make sure that the value is in the dictionary at the top
  dec_num = int(dec_num)
  if 0 <= dec_num <= 127:
    # this returns the value in the dictionary
    return dictionary_for_dec_to[dec_num]
  else:
    return "Invalid Input"
  
# converts the decimal number into the wanted unicode output format
def dec_to_unicode(dec_num):
  """
    Converts decimal to unicode.

    Args:
        dec_num

    Returns:
        unicode_output

    Raises:
        ValueError: If Brakes

    Note:
        None
    """
  # Unicode is the same as hex but with a U+ so i just took the kex code from before and change it to have a U+ infront
  hex_output = dec_to_hex(dec_num)
  unicode_output = (f"U+00{hex_output}")

  return unicode_output

# converts the decimal number into the wanted text output format
def dec_to_text(dec_num):
  """
    Converts decimal to text.

    Args:
        dec_num

    Returns:
        binary_text

    Raises:
        ValueError: If Brakes or if number is not between 0-127

    Note:
        None
    """
  # again changes the dec_num to int and checks if the number is in between 0 and 127 to make sure that the value is in the dictionary at the top
  dec_num = int(dec_num)
  if 0 <= dec_num <= 127:
    # this returns the value in the dictionary
    return dictionary_for_dec_to[dec_num]
  else:
    return "Invalid Input"

