
from menu import format_input
# Entering the numbers and text

# Enters the Binary Number and splits into a list
def binary_enter():
  """
    Enters Binary number.

    Args:
        none

    Returns:
        binary_input

    Raises:
        ValueError: If Brakes

    Note:
        None
    """
  binary_input = input(f"Enter Your {format_input} number: ").split()
  return binary_input

# Enters The Hex Number and splits into a list
def hex_enter():
  """
    Enters hex number.

    Args:
        none

    Returns:
        hex_input

    Raises:
        ValueError: If Brakes

    Note:
        None
    """
  hex_input = input(f"Enter Your {format_input} number: ").split()
  return hex_input

#Enters The Unicode and splits into a list
def unicode_enter():
  """
    Enters unicode number.

    Args:
        none

    Returns:
        unicode_input

    Raises:
        ValueError: If Brakes

    Note:
        None
    """
  unicode_input = input(f"Enter Your {format_input} number: ").split()
  return unicode_input

#Enters The Ascii text
def ascii_enter():
  """
    Enters ascii number.

    Args:
        none

    Returns:
        ascii_input

    Raises:
        ValueError: If Brakes

    Note:
        None
    """
  ascii_input = input(f"Enter Your {format_input} text: ")
  return ascii_input

#Enters the Tex
def text_enter():
  """
    Enters text number.

    Args:
        none

    Returns:
        text_input

    Raises:
        ValueError: If Brakes

    Note:
        None
    """
  text_input = input(f"Enter Your {format_input}: ")
  return text_input

