Start

My Pseudocode is for helping me organizes where everything is is and how it would all work together. It shows me what would work and what would not. for example the asking to see with a if statement for all to see input then ask for output after all inputs are asked for. Putting how the actual functions and conversion work in the pseudocode does not really help me.



while True
Input your input type Binary, Hexadecimal, ASCII, Unicode, Text

Input your output type Binary, Hexadecimal, ASCII, Unicode, Text

if input = Binary, Hexadecimal, ASCII, Unicode, Text and output = Binary, Hexadecimal, ASCII, Unicode, Text
  break
else try again

<!-- inputs to decimal -->
def b-d
  convert binary to decimal
  dec

def h-d
  convert hex to decimal
  dec

def u-d
  convert unicode to decimal
  dec

def a-d
  converts ascii to decimal
  dec

def t-d
  converts text to decimal
  dec
<!-- decimal to outputs -->
def d-b
  converts decimal to binary
  binary

def d-h
  converts decimal to hex
  hex

def d-u
  converts decimal to unicode
  unicode

def d-a
  converts decimal to ascii
  ascii

def d-t
  converts decimal to text
  text

<!-- what input to call -->
if input = binary
  call b-d

if input = hex
  call h-d

if input = unicode
  call u-d

if input = ascii
  call a-d

if input = text
  call t-d

<!-- what output to call -->

if output = binary
  call d-b
  print binary

if output = hex
  call d-h
  print hex

if output = unicode
  call d-u
  print unicode

if output = ascii
  call d-a
  print ascii
  
if output = text
  call d-t
  print text