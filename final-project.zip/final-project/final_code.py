
import os
from dictionaries import dictionary_for_dec_to, hex_d
from enter_numbers import binary_enter, hex_enter, unicode_enter, ascii_enter, text_enter
from input_to_dec import binary_to_dec, hex_to_dec, unicode_to_dec, ascii_to_dec, text_to_dec
from dec_to_output import dec_to_binary, dec_to_hex, dec_to_unicode, dec_to_ascii, dec_to_text
from menu import format_input, format_output
os. system('cls')
# BEFORE RUNNING When entering what input or output you want you actually have to enter for example binary. The numbers will not work That is just to make it look nice.
while True:
  try:
    
    # This checks to see what input and output the user wants and runs the according functions
    dec_num = []
    
    # if the input is binary its runs the binary enter function to get the user to enter the binary number
    # next it runs a for loop so if there is muiltiple binary numbers it can run all
    # lastly it runs the binary to decimal function so that later it can be converted into the wanted output
    if format_input == "binary":
      binary_input = binary_enter()
      
      for n in binary_input:
        dec_num.append(binary_to_dec(n))


    # if the input is hex its runs the hex enter function to get the user to enter the hex number
    # next it runs a for loop so if there is muiltiple hex numbers it can run all
    # lastly it runs the hex to decimal function so that later it can be converted into the wanted output
    if format_input == "hexadecimal":
      hex_input = hex_enter()

      for n in hex_input:
        dec_num.append(hex_to_dec(n))

    # if the input is unicode its runs the unicode enter function to get the user to enter the unicode number
    # next it runs a for loop so if there is muiltiple unicode numbers it can run all
    # lastly it runs the unicode to decimal function so that later it can be converted into the wanted output
    if format_input == "unicode":
      unicode_input = unicode_enter()

      for n in unicode_input:
        dec_num.append(unicode_to_dec(n))


    # if the input is ascii its runs the ascii enter function to get the user to enter the ascii input
    # next it runs a for loop so if there is muiltiple unicode numbers it can run all
    # lastly it runs the ascii to decimal function so that later it can be converted into the wanted output
    if format_input == "ascii":
      ascii_input = str(ascii_enter())
    
      for n in ascii_input:
        dec_num.append(str(ascii_to_dec(n)))


    # if the input is text its runs the text enter function to get the user to enter the text input
    # next it runs a for loop so if there is muiltiple unicode numbers it can run all
    # lastly it runs the text to decimal function so that later it can be converted into the wanted output
    # You Can Not add spaces in between words when entering a word
    if format_input == "text":
      text_input = str(text_enter())
      
      for n in text_input:
        dec_num.append(str(text_to_dec(n)))

    # this tells the user what type of output they asked for
    print(f"Your {format_output} is: ")


    # This is if you enter blank on the output then it calls a function to be exported


    # if the output is binary it runs a for loop so if there is muiltiple decimal numbers it can run all
    # lastly it runs the decimal to binary function and prints the final output
    if format_output == "binary":
      for n in dec_num:
        binary_output = dec_to_binary(n)
        print(binary_output)


    # if the output is hexadecimal it runs a for loop so if there is muiltiple decimal numbers it can run all
    # lastly it runs the decimal to hexadecimal function and prints the final output
    if format_output == "hexadecimal":
      for n in dec_num:
        hex_output = dec_to_hex(n)
        print(hex_output)


    # if the output is text it runs a for loop so if there is muiltiple decimal numbers it can run all
    # lastly it runs the decimal to text function and prints the final output
    if format_output == "text":
      for n in dec_num:
        text_output = dec_to_text(n)
        print(text_output)


    # if the output is ascii it runs a for loop so if there is muiltiple decimal numbers it can run all
    # lastly it runs the decimal to ascii function and prints the final output
    if format_output == "ascii":
      for n in dec_num:
        ascii_output = dec_to_ascii(n)
        print(ascii_output)


    # if the output is unicode it runs a for loop so if there is muiltiple decimal numbers it can run all
    # lastly it runs the decimal to unicode function and prints the final output
    if format_output == "unicode":
      for n in dec_num:
        unicode_output = dec_to_unicode(n)
        print(unicode_output)


    exit = input("Would You Like To Exit: ")
    exit = exit.lower()
    if exit == "yes":
      print("GoodBye")
      break
    elif exit != "no":
      print("Invalid Input")

  except:
    os. system('cls')
    print("Invalid Input, Something has gone Wrong")
