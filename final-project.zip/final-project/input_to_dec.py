from dictionaries import *

# Takes The Number or text and converts it to decimal

# Takes The Inputed Binary and converts to decimal
def binary_to_dec(binary_input):
  """
    Converts binary to decimal.

    Args:
        binary_input

    Returns:
        dec_num

    Raises:
        ValueError: If Brakes

    Note:
        None
    """
  # Setting variables
  count = 1
  dec_num = 0
  #converts the binary input to an int so it works for the while loop
  binary_input = int(binary_input)

  #actually converts the binary to decimals pretty basic
  while binary_input > 0:
    rem = binary_input % 10
    binary_input = binary_input//10
    dec_num += rem*count
    count = count*2

  return dec_num

# Takes The Inputed Hex and converts to decimal this way I did not use a normal dictionary because when i did it broke everything
# It did not like converting with lists so I found another way of doing it online.
def hex_to_dec(hex_input):
  """
    Converts hex to decimal.

    Args:
        hex_input

    Returns:
        dec_num

    Raises:
        ValueError: If Brakes or digit not in hex_digits

    Note:
        None
    """
  # Setting variables
  dec = 0
  count = 0

  # Changes the hexinput to uppercase so if the user types 1a it works
  hex_digits = "0123456789ABCDEF"
  hex_input = hex_input.upper()

  # in the for loop when the digits in the reversed number of my hex input it runs and in the if statement it uses .index
  # to determine the number or letter in the digit and the rest is pretty basic
  for digit in reversed(hex_input):
    if digit in hex_digits:
      dec = dec + hex_digits.index(digit) * 16 ** count
      count = count + 1
    else:
      raise ValueError("Invalid Input")
  return dec
  

# Takes The Inputed ascii and converts to decimal
def ascii_to_dec(ascii_input):
  """
    Converts ascii to decimal.

    Args:
        ascii_input

    Returns:
        dec_num

    Raises:
        ValueError: If Brakes

    Note:
        None
    """
  # This line takes the key from the dictionary at the top and makes the key of the ascii input dec_num
  dec_num = (list(dictionary_for_dec_to.keys())[list(dictionary_for_dec_to.values()).index(ascii_input)])
  return dec_num

# Takes The Inputed text and converts to decimal
def text_to_dec(text_input):
  """
    Converts text to decimal.

    Args:
        text_input

    Returns:
        dec_num

    Raises:
        ValueError: If Brakes

    Note:
        None
    """
  # This line takes the key from the dictionary at the top and makes the key of the text input dec_num
  dec_num = (list(dictionary_for_dec_to.keys())[list(dictionary_for_dec_to.values()).index(text_input)])
  return dec_num

# Takes The Inputed Unicode and converts to decimal
def unicode_to_dec(unicode_input):
  """
    Converts unicode to decimal.

    Args:
        unicode_input

    Returns:
        dec_num

    Raises:
        ValueError: If Brakes and if unicode is invalid input without the U+

    Note:
        None
    """
  # if the input starts with a U+
  if unicode_input.startswith("U+00"):
        # Remove the "U+" 
        dec_num = unicode_input[4:]
        return dec_num
  else:
    print("Your unicode was an Invalid Input")
