import os
try:
  while True:
    os. system('cls')
    print("Input Choices")
    print("1. Binary")
    print("2. Hexadecimal")
    print("3. ASCII")
    print("4. Unicode")
    print("5. Text")

    format_input = input("Enter Your Input Type: ")
    format_input = str.lower(format_input)
    print("Output Choices")
    print("1. Binary")
    print("2. Hexadecimal")
    print("3. ASCII")
    print("4. Unicode")
    print("5. Text")

    format_output = input("Enter Your Output Type: ")
    format_output = str.lower(format_output)
    if format_input == "binary" or format_input == "hexadecimal" or format_input == "ascii" or format_input == "unicode" or format_input == "text" and  format_output == "binary" or format_output == "hexadecimal" or format_output == "ascii" or format_output == "unicode" or format_output == "text":
      print(f"You chose {format_output} as your output format")
      break
    else:
      print("Invalid Input")
except:
    print("Invalid Input, Something went wrong")

  